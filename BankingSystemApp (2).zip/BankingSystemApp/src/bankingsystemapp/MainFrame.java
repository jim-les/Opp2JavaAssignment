/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingsystemapp;
import javax.swing.*;

public class MainFrame extends JFrame {
    private CardLayout cardLayout;
    private JPanel cardsPanel;

    public MainFrame() {
        setTitle("Banking System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        cardsPanel = new JPanel(cardLayout);

        cardsPanel.add(new LoginSignupPanel(cardsPanel), "LOGIN_SIGNUP");
        cardsPanel.add(new LandingPanel(cardsPanel), "LANDING");
        cardsPanel.add(new SettingsPanel(cardsPanel), "SETTINGS");

        cardLayout.show(cardsPanel, "LOGIN_SIGNUP"); // Start with the login/signup page

        add(cardsPanel);
    }
}
