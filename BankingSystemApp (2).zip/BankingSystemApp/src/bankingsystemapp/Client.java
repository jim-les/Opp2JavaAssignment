/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingsystemapp;

/**
 *
 * @author user
 */
public class Client {
    private String username;
    private String password;
    private double balance;
    private StringBuilder transactionLog;

    public Client(String username, String password) {
        this.username = username;
        this.password = password;
        this.balance = 0.0;
        this.transactionLog = new StringBuilder();
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public double getBalance() {
        return balance;
    }

    public String getTransactionLog() {
        return transactionLog.toString();
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            transactionLog.append("Deposited: $").append(amount).append("\n");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            transactionLog.append("Withdrawn: $").append(amount).append("\n");
        }
    }

    @Override
    public String toString() {
        return "Client{" +
                "username='" + username + '\'' +
                ", balance=" + balance +
                '}';
    }
}


