/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingsystemapp;

/**
 *
 * @author user
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginSignupPanel extends JPanel {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginSignupPanel(JPanel cardsPanel) {
        setLayout(new GridLayout(4, 2));

        JLabel titleLabel = new JLabel("Login / Signup");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        add(titleLabel);

        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField();
        add(usernameLabel);
        add(usernameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();
        add(passwordLabel);
        add(passwordField);

        JButton loginButton = new JButton("Login");
        JButton signupButton = new JButton("Signup");

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                char[] passwordChars = passwordField.getPassword();
                String password = new String(passwordChars);

                // Perform login logic
                if (Bank.authenticateUser(username, password)) {
                    cardLayout.show(cardsPanel, "LANDING");
                } else {
                    JOptionPane.showMessageDialog(LoginSignupPanel.this, "Login failed. Invalid credentials.");
                }
            }
        });

        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                char[] passwordChars = passwordField.getPassword();
                String password = new String(passwordChars);

                // Perform signup logic
                Bank.createAccount(username, password);
                JOptionPane.showMessageDialog(LoginSignupPanel.this, "Signup successful. You can now log in.");
            }
        });

        add(new JLabel());
        add(loginButton);
        add(new JLabel());
        add(signupButton);
    }
}
