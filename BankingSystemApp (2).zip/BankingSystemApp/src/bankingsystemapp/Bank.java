/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingsystemapp;

/**
 *
 * @author user
 */
import java.util.ArrayList;

public class Bank {
    private static ArrayList<Client> clients = new ArrayList<>();
    private static String currentUsername;

    public static boolean authenticateUser(String username, String password) {
        for (Client client : clients) {
            if (client.getUsername().equals(username) && client.getPassword().equals(password)) {
                currentUsername = username;
                return true;
            }
        }
        return false;
    }

    public static void createAccount(String username, String password) {
        clients.add(new Client(username, password));
    }

    public static double getClientBalance(String username) {
        for (Client client : clients) {
            if (client.getUsername().equals(username)) {
                return client.getBalance();
            }
        }
        return 0.0; // Return a default balance if not found
    }

    public static String getCurrentUsername() {
        return currentUsername;
    }
}

