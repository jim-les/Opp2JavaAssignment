package BankingSystemApp;

import javax.swing.*;

public class BankingSystemApp{
    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
//                new MainFrame().setVisible(true);
                  System.out.println("Banking system");
            }
        });
    }
}
